import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import DoRightLogo from './DoRightLogo';
import { colors, fontWeights } from '../styles/theme';
import { FOOTER } from '../data/siteContent';

export default function Footer() {
  return (
    <footer role="contentinfo" style={{ background: colors.white, borderTop: `1px solid ${colors.border}`, padding: '52px 0 0' }}>
      <div style={{ maxWidth: '1180px', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: '40px', alignItems: 'start', paddingBottom: '40px' }}>

          {/* Brand */}
          <div>
            <Link to="/" aria-label="DoRight" style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
              <DoRightLogo size={32} />
              <span style={{ fontSize: '16px', fontWeight: fontWeights.extrabold, fontFamily: "'Plus Jakarta Sans','Inter',sans-serif" }}>
                <span style={{ color: colors.primary }}>do</span>
                <span style={{ color: colors.dark }}>right</span>
              </span>
            </Link>
            <p style={{ fontSize: '12.5px', color: colors.gray, lineHeight: 1.7, maxWidth: '200px' }}>{FOOTER.tagline}</p>
          </div>

          {/* Link columns */}
          {FOOTER.columns.map(col => (
            <div key={col.title}>
              <h4 style={{ fontSize: '13px', fontWeight: fontWeights.bold, color: colors.dark, marginBottom: '14px' }}>{col.title}</h4>
              <nav aria-label={col.title}>
                {col.links.map(l => (
                  <Link key={l.label} to={l.href} style={{ display: 'block', fontSize: '13px', color: colors.gray, lineHeight: 2, transition: 'color 0.15s' }}
                    onMouseEnter={e => (e.currentTarget.style.color = colors.primary)}
                    onMouseLeave={e => (e.currentTarget.style.color = colors.gray)}
                  >
                    {l.label}
                  </Link>
                ))}
              </nav>
            </div>
          ))}

          {/* Social */}
          <div>
            <h4 style={{ fontSize: '13px', fontWeight: fontWeights.bold, color: colors.dark, marginBottom: '14px' }}>Follow Us</h4>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {FOOTER.social.map(s => (
                <motion.a key={s.label} href={s.href} aria-label={s.label}
                  whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                  style={{
                    width: '32px', height: '32px', borderRadius: '8px',
                    background: colors.primaryLight, color: colors.primary,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '12px', fontWeight: fontWeights.bold,
                    border: `1px solid ${colors.primaryBorder}`,
                  }}
                >
                  {s.icon}
                </motion.a>
              ))}
            </div>
          </div>
        </div>

        <div style={{ borderTop: `1px solid ${colors.border}`, padding: '16px 0', textAlign: 'center' }}>
          <p style={{ fontSize: '12px', color: colors.grayLight }}>{FOOTER.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
