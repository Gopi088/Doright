declare module "*.avif";
declare module "*.jpg";
declare module "*.jpeg";
declare module "*.png";
declare module "*.webp";